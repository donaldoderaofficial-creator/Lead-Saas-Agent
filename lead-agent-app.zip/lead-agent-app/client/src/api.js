const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:4000";

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  base: API_BASE,
  getLeads: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/api/leads${qs ? `?${qs}` : ""}`);
  },
  getStats: () => request("/api/stats"),
  createLead: (data) =>
    request("/api/leads", { method: "POST", body: JSON.stringify(data) }),
  updateLeadStatus: (id, status) =>
    request(`/api/leads/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),
};
