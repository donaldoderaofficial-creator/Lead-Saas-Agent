import { useCallback, useEffect, useState } from "react";
import { io } from "socket.io-client";
import { api } from "./api.js";
import StatsBar from "./components/StatsBar.jsx";
import LeadQueue from "./components/LeadQueue.jsx";
import LeadCaptureForm from "./components/LeadCaptureForm.jsx";

export default function App() {
  const [leads, setLeads] = useState([]);
  const [stats, setStats] = useState(null);
  const [loadError, setLoadError] = useState(null);

  const refresh = useCallback(async () => {
    try {
      const [leadRows, statRows] = await Promise.all([api.getLeads(), api.getStats()]);
      setLeads(leadRows);
      setStats(statRows);
      setLoadError(null);
    } catch (err) {
      setLoadError(err.message);
    }
  }, []);

  useEffect(() => {
    refresh();

    const socket = io(api.base, { transports: ["websocket"] });

    socket.on("lead:new", (lead) => {
      setLeads((prev) => [lead, ...prev]);
      refresh(); // keep stats in sync too
    });

    socket.on("lead:update", (updated) => {
      setLeads((prev) => prev.map((l) => (l.id === updated.id ? updated : l)));
      refresh();
    });

    return () => socket.disconnect();
  }, [refresh]);

  async function handleBook(id) {
    await api.updateLeadStatus(id, "booked");
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="logo">
          <span className="dot" />
          Dispatch
        </div>
        {stats && <span className="header-sub">{stats.total} leads tracked</span>}
      </header>

      {loadError && (
        <div className="banner-error">
          Could not reach the API at {api.base}. Is the server running? ({loadError})
        </div>
      )}

      <StatsBar stats={stats} />

      <main className="main-grid">
        <LeadQueue leads={leads} onBook={handleBook} />
        <LeadCaptureForm onSubmitted={() => refresh()} />
      </main>
    </div>
  );
}
