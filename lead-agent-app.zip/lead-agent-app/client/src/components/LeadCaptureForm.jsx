import { useState } from "react";
import { api } from "../api.js";

const initial = { name: "", email: "", company: "", message: "" };

export default function LeadCaptureForm({ onSubmitted }) {
  const [form, setForm] = useState(initial);
  const [status, setStatus] = useState("idle"); // idle | sending | error
  const [error, setError] = useState(null);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus("sending");
    setError(null);
    try {
      const lead = await api.createLead({ ...form, source: "form" });
      onSubmitted(lead);
      setForm(initial);
      setStatus("idle");
    } catch (err) {
      setError(err.message);
      setStatus("error");
    }
  }

  return (
    <form className="capture-form" onSubmit={handleSubmit}>
      <h3>Talk to Dispatch</h3>
      <p className="form-sub">Submit a demo request — the agent qualifies it live.</p>

      <label>
        Name
        <input
          required
          value={form.name}
          onChange={(e) => update("name", e.target.value)}
          placeholder="Jane Kimani"
        />
      </label>

      <label>
        Work email
        <input
          required
          type="email"
          value={form.email}
          onChange={(e) => update("email", e.target.value)}
          placeholder="jane@company.com"
        />
      </label>

      <label>
        Company
        <input
          value={form.company}
          onChange={(e) => update("company", e.target.value)}
          placeholder="Company name"
        />
      </label>

      <label>
        What are you trying to solve?
        <textarea
          rows={3}
          value={form.message}
          onChange={(e) => update("message", e.target.value)}
          placeholder="e.g. Budget approved, need this live in two weeks."
        />
      </label>

      {error && <div className="form-error">{error}</div>}

      <button type="submit" className="btn-primary" disabled={status === "sending"}>
        {status === "sending" ? "Sending…" : "Send to Dispatch"}
      </button>
    </form>
  );
}
