export default function LeadQueue({ leads, onBook }) {
  return (
    <div className="panel">
      <div className="panel-head">
        <span>INBOUND_QUEUE</span>
        <span className="live">
          <span className="pulse" />
          LIVE
        </span>
      </div>

      {leads.length === 0 && (
        <div className="lead-row empty">No leads yet — submit the form to see one land here.</div>
      )}

      {leads.map((lead) => (
        <div className="lead-row" key={lead.id}>
          <div>
            <span className="name">{lead.name}</span>
            <span className="co">{lead.company || "—"}</span>
          </div>
          <span className={`badge ${lead.status}`}>{lead.status}</span>
          <span className="score">{lead.score ?? "—"}</span>
          {lead.status === "qualified" && (
            <button className="mini-btn" onClick={() => onBook(lead.id)}>
              Book
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
