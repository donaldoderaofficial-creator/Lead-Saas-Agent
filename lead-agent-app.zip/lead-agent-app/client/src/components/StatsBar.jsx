function formatMs(ms) {
  if (!ms) return "—";
  const seconds = Math.round(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  return `${Math.round(seconds / 60)}m`;
}

export default function StatsBar({ stats }) {
  if (!stats) return null;

  const items = [
    { label: "MEDIAN_RESPONSE", value: formatMs(stats.medianResponseMs) },
    { label: "NEW", value: stats.byStatus.new },
    { label: "QUALIFIED", value: stats.byStatus.qualified },
    { label: "BOOKED", value: stats.byStatus.booked },
  ];

  return (
    <div className="stats-bar">
      {items.map((item) => (
        <div className="stat-item" key={item.label}>
          <div className="stat-num">{item.value}</div>
          <div className="stat-lbl">{item.label}</div>
        </div>
      ))}
    </div>
  );
}
