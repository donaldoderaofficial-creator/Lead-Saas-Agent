import { Server } from "socket.io";

let io = null;

export function initSocket(httpServer, clientOrigin) {
  io = new Server(httpServer, {
    cors: { origin: clientOrigin, methods: ["GET", "POST"] },
  });

  io.on("connection", (socket) => {
    socket.emit("connected", { ok: true });
  });

  return io;
}

export function getIO() {
  if (!io) throw new Error("Socket.io not initialized — call initSocket() first.");
  return io;
}
