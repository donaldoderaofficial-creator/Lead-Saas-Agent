/**
 * Heuristic qualification scorer.
 *
 * This is a deliberately simple, explainable rules engine so the demo
 * has no external dependency. In production, replace/augment with an
 * LLM-based classifier (see README) that reasons over the full message
 * plus enrichment data (company size, funding, tech stack).
 */

const URGENCY_WORDS = ["asap", "urgent", "this week", "two weeks", "next quarter", "immediately", "soon"];
const BUDGET_WORDS = ["budget approved", "budget", "contract", "purchase", "pricing", "move forward"];
const LOW_INTENT_WORDS = ["just looking", "not urgent", "just browsing", "curious"];

export function qualify(lead) {
  const text = `${lead.message ?? ""}`.toLowerCase();
  let score = 40; // baseline

  if (URGENCY_WORDS.some((w) => text.includes(w))) score += 20;
  if (BUDGET_WORDS.some((w) => text.includes(w))) score += 25;
  if (LOW_INTENT_WORDS.some((w) => text.includes(w))) score -= 25;
  if (lead.company) score += 5;
  if (text.length > 80) score += 5; // detailed messages tend to be more serious

  score = Math.max(5, Math.min(99, score));

  const threshold = Number(process.env.QUALIFY_THRESHOLD ?? 60);
  const status = score >= threshold ? "qualified" : "new";

  return { score, status };
}
