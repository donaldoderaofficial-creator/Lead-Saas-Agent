import "dotenv/config";
import express from "express";
import http from "node:http";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

import { leadsRouter } from "./routes/leads.js";
import { statsRouter } from "./routes/stats.js";
import { initSocket } from "./socket.js";

const PORT = process.env.PORT ?? 4000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN ?? "http://localhost:5173";

const app = express();

app.use(helmet());
app.use(cors({ origin: CLIENT_ORIGIN }));
app.use(express.json({ limit: "100kb" }));

// Basic abuse protection on the public capture endpoint.
const captureLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api/leads", captureLimiter);

app.get("/health", (req, res) => res.json({ ok: true }));
app.use("/api/leads", leadsRouter);
app.use("/api/stats", statsRouter);

app.use((err, req, res, next) => {
  console.error(err); // eslint-disable-line no-console
  res.status(500).json({ error: "Internal server error" });
});

const httpServer = http.createServer(app);
initSocket(httpServer, CLIENT_ORIGIN);

httpServer.listen(PORT, () => {
  console.log(`Dispatch API listening on :${PORT}`); // eslint-disable-line no-console
});
