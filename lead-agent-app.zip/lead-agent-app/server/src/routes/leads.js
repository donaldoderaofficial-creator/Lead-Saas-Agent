import { Router } from "express";
import { listLeads, getLead, createLead, updateLead } from "../db.js";
import { qualify } from "../qualify.js";
import { getIO } from "../socket.js";

export const leadsRouter = Router();

// GET /api/leads?status=qualified&minScore=70
leadsRouter.get("/", (req, res) => {
  const { status, minScore } = req.query;
  res.json(listLeads({ status, minScore }));
});

leadsRouter.get("/:id", (req, res) => {
  const lead = getLead(req.params.id);
  if (!lead) return res.status(404).json({ error: "Lead not found" });
  res.json(lead);
});

// POST /api/leads  — inbound capture from forms/chat/email webhooks
leadsRouter.post("/", (req, res) => {
  const { name, email, company, message, source } = req.body ?? {};

  if (!name || !email) {
    return res.status(400).json({ error: "name and email are required" });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: "email is invalid" });
  }

  const lead = createLead({ name, email, company, message, source });

  // Run the agent's qualification pass immediately, then mark it responded.
  const { score, status } = qualify(lead);
  const finalLead = updateLead(lead.id, { score, status, respondedAt: Date.now() });

  getIO().emit("lead:new", finalLead);
  res.status(201).json(finalLead);
});

// PATCH /api/leads/:id — move a lead through the pipeline (e.g. booked)
leadsRouter.patch("/:id", (req, res) => {
  const { status } = req.body ?? {};
  const allowed = ["new", "qualified", "booked"];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${allowed.join(", ")}` });
  }
  const updated = updateLead(req.params.id, { status });
  if (!updated) return res.status(404).json({ error: "Lead not found" });

  getIO().emit("lead:update", updated);
  res.json(updated);
});

// POST /api/leads/:id/requalify — re-run the scoring engine
leadsRouter.post("/:id/requalify", (req, res) => {
  const lead = getLead(req.params.id);
  if (!lead) return res.status(404).json({ error: "Lead not found" });

  const { score, status } = qualify(lead);
  const updated = updateLead(req.params.id, { score, status, respondedAt: Date.now() });

  getIO().emit("lead:update", updated);
  res.json(updated);
});
