import { Router } from "express";
import { stats } from "../db.js";

export const statsRouter = Router();

statsRouter.get("/", (req, res) => {
  res.json(stats());
});
