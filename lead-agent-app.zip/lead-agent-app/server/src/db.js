import { nanoid } from "nanoid";

/**
 * In-memory store, intentionally dependency-free so the demo runs with
 * zero setup. Swap this module for a Postgres (Prisma) or Mongo adapter
 * before going to production — see README "Improvements" section.
 */
const leads = new Map();

function seed() {
  const now = Date.now();
  const seedLeads = [
    { name: "R. Alvarez", company: "Northwind Freight", email: "r.alvarez@northwindfreight.com",
      message: "We need this rolled out to our 40-person sales team by next quarter, budget approved.",
      source: "form", status: "booked", score: 92, createdAt: now - 1000 * 60 * 60 * 5, respondedAt: now - 1000 * 60 * 60 * 5 + 9000 },
    { name: "T. Okafor", company: "Vale Robotics", email: "t.okafor@valerobotics.io",
      message: "Evaluating a few tools, want to see pricing for a mid-size team.",
      source: "chat", status: "qualified", score: 78, createdAt: now - 1000 * 60 * 60 * 3, respondedAt: now - 1000 * 60 * 60 * 3 + 14000 },
    { name: "S. Lindqvist", company: "Birchwood Capital", email: "s.lindqvist@birchwoodcap.com",
      message: "Just looking around, not urgent.",
      source: "form", status: "new", score: null, createdAt: now - 1000 * 60 * 20, respondedAt: null },
    { name: "M. Dube", company: "Kanu Retail Group", email: "m.dube@kanuretail.co",
      message: "Our current process is too slow, we're losing leads over the weekend. Need something live in two weeks.",
      source: "email", status: "qualified", score: 81, createdAt: now - 1000 * 60 * 60 * 2, respondedAt: now - 1000 * 60 * 60 * 2 + 8000 },
    { name: "A. Petrova", company: "Solenne Labs", email: "a.petrova@solennelabs.com",
      message: "Ready to move forward, please send a contract.",
      source: "form", status: "booked", score: 95, createdAt: now - 1000 * 60 * 60 * 6, respondedAt: now - 1000 * 60 * 60 * 6 + 6000 },
  ];
  for (const lead of seedLeads) {
    const id = nanoid(10);
    leads.set(id, { id, ...lead });
  }
}
seed();

export function listLeads({ status, minScore } = {}) {
  let rows = Array.from(leads.values());
  if (status) rows = rows.filter((l) => l.status === status);
  if (minScore != null) rows = rows.filter((l) => (l.score ?? 0) >= Number(minScore));
  return rows.sort((a, b) => b.createdAt - a.createdAt);
}

export function getLead(id) {
  return leads.get(id) ?? null;
}

export function createLead(data) {
  const id = nanoid(10);
  const lead = {
    id,
    name: data.name,
    company: data.company ?? "",
    email: data.email,
    message: data.message ?? "",
    source: data.source ?? "form",
    status: "new",
    score: null,
    createdAt: Date.now(),
    respondedAt: null,
  };
  leads.set(id, lead);
  return lead;
}

export function updateLead(id, patch) {
  const existing = leads.get(id);
  if (!existing) return null;
  const updated = { ...existing, ...patch };
  leads.set(id, updated);
  return updated;
}

export function stats() {
  const rows = Array.from(leads.values());
  const responded = rows.filter((l) => l.respondedAt);
  const responseTimes = responded.map((l) => l.respondedAt - l.createdAt).sort((a, b) => a - b);
  const median = responseTimes.length
    ? responseTimes[Math.floor(responseTimes.length / 2)]
    : 0;

  return {
    total: rows.length,
    byStatus: {
      new: rows.filter((l) => l.status === "new").length,
      qualified: rows.filter((l) => l.status === "qualified").length,
      booked: rows.filter((l) => l.status === "booked").length,
    },
    medianResponseMs: median,
  };
}
