# Dispatch — Lead Agent (full stack demo)

A working backend + React dashboard for the Dispatch landing page: leads
come in through a form, get scored by a qualification engine, and appear
live in the pipeline queue via WebSockets.

## Structure

```
server/   Node.js + Express API, Socket.io, in-memory lead store
client/   React (Vite) dashboard: live queue, stats bar, capture form
```

## Run it

**Backend**
```bash
cd server
cp .env.example .env
npm install
npm run dev        # http://localhost:4000
```

**Frontend** (new terminal)
```bash
cd client
npm install
npm run dev         # http://localhost:5173
```

Open the client, submit the form — the lead is scored instantly and
appears in the queue in real time, and again in a second browser tab.

## API

| Method | Path                       | Purpose                          |
|--------|----------------------------|-----------------------------------|
| GET    | `/api/leads`               | List leads (`?status=`, `?minScore=`) |
| GET    | `/api/leads/:id`           | Get one lead                     |
| POST   | `/api/leads`                | Capture + auto-qualify a new lead |
| PATCH  | `/api/leads/:id`            | Update status (e.g. `booked`)    |
| POST   | `/api/leads/:id/requalify`  | Re-run the scoring engine        |
| GET    | `/api/stats`                | Pipeline counts + median response |

Socket.io events: `lead:new`, `lead:update`.

## Necessary improvements before this is production-ready

**Data & reliability**
- Swap the in-memory `Map` in `server/src/db.js` for Postgres (Prisma) or
  Mongo — right now every restart wipes all leads.
- Add idempotency keys on `POST /api/leads` so a retried webhook or a
  double form-submit doesn't create duplicate leads.
- Add a real job queue (BullMQ + Redis) between capture and qualification
  so scoring, enrichment, and outreach don't block the HTTP response.

**Qualification quality**
- The scorer in `qualify.js` is a transparent keyword heuristic for the
  demo. Replace or augment it with an LLM-based classifier that reasons
  over the full message plus firmographic enrichment (company size,
  industry, funding) — and log its reasoning so scores are auditable.
- Add a feedback loop: when a sales rep marks a "qualified" lead as a bad
  fit, feed that back into the scoring rules/model.

**Security**
- Add authentication (API keys for inbound webhooks, JWT/session auth for
  the dashboard) — right now any client can read and write every lead.
- Validate/sanitize all inputs with a schema library (zod) instead of
  hand-rolled checks.
- Lock CORS down to known origins in production, and verify signatures on
  any inbound webhook sources (form provider, email parser, chat widget).
- Rate-limit per API key/IP more granularly, and add request logging
  (pino) for audit trails.

**Integrations that make it real**
- Actual outbound messaging via SendGrid/Postmark (email) and Twilio
  (SMS) so "Engage" is a real step, not just a status change.
- Real calendar booking via Google Calendar / Calendly API for the "Book"
  stage.
- Inbound source connectors: web form webhook, shared inbox parser (e.g.
  via Gmail API), and a chat widget event stream.

**Ops**
- Environment-based config and secrets management (not `.env` files in
  production).
- Structured logging + error tracking (Sentry) and basic metrics
  (response time, qualification rate) exported to a dashboard.
- Tests: unit tests for `qualify.js` scoring rules, integration tests for
  the API routes, and a couple of end-to-end tests for the capture →
  queue flow.
- Deployment split: the frontend (`client/`) can go straight to Netlify
  as a static build. The backend needs a host that keeps a Node process
  alive for Socket.io (Render, Railway, Fly.io, or a container on
  whichever cloud you already use) — Netlify's functions are
  short-lived and won't hold a WebSocket connection open.
